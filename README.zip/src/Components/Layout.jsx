import React from 'react';
import Header from '../Components/Header'; // Import the Header component

const Layout = ({ children }) => {
  return (
    <div>
      <Header /> {/* This will display the header */}
      <main>
        {children} {/* This is where the content passed from other components will be rendered */}
      </main>
    </div>
  );
};

export default Layout;
