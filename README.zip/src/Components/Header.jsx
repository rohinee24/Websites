import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // Bootstrap Import
import '../Css/Header.css';

const Header = () => {
    const [isNavOpen, setIsNavOpen] = useState(false);

    const toggleNavbar = () => {
        setIsNavOpen(!isNavOpen);
    };

    return (
        <header className="header">
            <div className="container-fluid">
                {/* First Row - Logo, Cart, and Toggle Button (For Small Screens) */}
                {/* First Row - Shown only on SMALL SCREENS (mobile) */}
          {/* First Row - Shown on SMALL & TABLETS, hides only on large screens */}
<div className="row align-items-center py-2 d-lg-none"> 


                    {/* Logo */}
                    <div className="col-6 text-start">
                        <div className="logo">
                            <a href="/">ShopLogo</a>
                        </div>
                    </div>

                    {/* Cart Icon */}
                    <div className="col-4 text-center">
                        <div className="cart">
                            <a href="#" className="cart-link">
                                <span className="cart-icon">&#x1F6D2;</span> {/* Cart Icon */}
                                <span className="cart-count">0</span> {/* Cart Count */}
                            </a>
                        </div>
                    </div>

                    {/* Navbar Toggle Button */}
                    <div className="col-2 text-end">
                        {/* Navbar Toggle Icon (Without Button) */}

                        <span
                            className="navbar-toggle-icon"
                            onClick={toggleNavbar}
                        >
                            ☰ {/* Hamburger Icon */}
                        </span>


                    </div>
                </div>
<div className="row align-items-center d-none d-lg-flex">


                    {/* Logo */}
                    <div className="col-md-4 col-lg-4 text-start">
                        <div className="logo">
                            <a href="/">Logo</a>
                        </div>
                    </div>

                    {/* Menu */}
                    <div className="col-md-6 col-lg-6">
                        <nav className="navbar navbar-expand-lg">
                            <div className={`navbar-collapse ${isNavOpen ? 'show' : 'collapse'}`} id="navbarNav">
                                <ul className="navbar-nav mx-auto">
                                    <li className="nav-item">
                                        <a className="nav-link" href="/">Home</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="/shop">About</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">Courses</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="/contact">Contact</a>
                                    </li>
                                    
                                </ul>
                            </div>
                        </nav>
                    </div>

                    {/* Cart Icon */}
                    <div className="col-md-2 col-lg-2 text-end">
                        <div className="cart">
                            <a href="#" className="cart-link">
                                <span className="cart-icon">&#x1F6D2;</span> {/* Cart Icon */}
                                <span className="cart-count">0</span> {/* Cart Count */}
                            </a>
                        </div>
                    </div>
                </div>

                {/* Small Screen Navbar (Controlled by State) */}
                <div className={`row d-md-none ${isNavOpen ? 'show' : 'collapse'}`}>
                    <nav className="navbar navbar-light">
                        <div className="container">
                            <ul className="navbar-nav w-100 text-center">
                                <li className="nav-item">
                                    <a className="nav-link" href="/">Home</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="/shop">About</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Deals</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="/contact">Contact</a>
                                </li>
                               
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </header>
    );
};

export default Header;
