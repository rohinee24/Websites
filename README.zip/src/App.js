import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'; 
import Home from './Pages/Home';  // Correct path
import Aboutus from './Pages/Aboutus'; // Use lowercase "shop"
import Contact from './Pages/Contact'; // Use lowercase "shop"
import "bootstrap-icons/font/bootstrap-icons.css";

import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <Router>
      <div>
        <Routes>
          {/* Default redirect to /login when accessing / */}
          <Route path="/" element={<Navigate to="/home" />} />
          
          {/* Login route */}
          <Route path="/home" element={<Home />} /> {/* This uses the Home component */}

             <Route path="/shop" element={<Aboutus />} /> {/* Fixed capitalization */}
             <Route path="/contact" element={<Contact />} /> {/* Fixed capitalization */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
